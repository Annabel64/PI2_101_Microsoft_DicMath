import os

from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename

import pandas as pd

import azure.cognitiveservices.speech as speechsdk
from pydub import AudioSegment

from saytex import Saytex 
import matplotlib
import matplotlib.pyplot as plt

def Speaker_Choice(language="fr", gender="male"):
    speaker_dict = {"fr": ["fr-FR-AlainNeural", "fr-FR-CelesteNeural"],
                    "en": ["en-GB-AlfieNeural", "en-US-AmberNeural"],
                    "es": ["es-ES-AlvaroNeural", "es-ES-AbrilNeural"],
                    "de": ["de-DE-BerndNeural", "de-DE-AmalaNeural"]}
    return speaker_dict[language][0] if gender == "male" else speaker_dict[language][1]

def text2speech(text, lang='fr', gender="female"):
    cle = "4c9e5aae707e41518A148720a8b56c11"
    region = "francecentral"
    speech_config = speechsdk.SpeechConfig(subscription=cle, region=region)
    audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)

    # The language of the voice that speaks.
    #speech_config.speech_synthesis_voice_name = 'fr-FR-CelesteNeural'
    speech_config.speech_synthesis_voice_name = Speaker_Choice(gender=gender, language=lang)

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()

    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("Speech synthesized for text [{}]".format(text))
    elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_synthesis_result.cancellation_details
        print("Speech synthesis canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            if cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
                print("Did you set the speech resource key and region values?")

def Speech_To_Text(filepath,spoken_language="en-US"):
    # Set Configs
    cle = "4c9e5aae707e41518A148720a8b56c11"
    region = "francecentral"
    speech_config = speechsdk.SpeechConfig(subscription=cle, region=region)
    speech_config.speech_recognition_language=spoken_language
    audio_input = speechsdk.AudioConfig(filename=filepath)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)
    # Get Result
    speech_recognition_result = speech_recognizer.recognize_once_async().get()
    if speech_recognition_result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return speech_recognition_result.text
    elif speech_recognition_result.reason == speechsdk.ResultReason.NoMatch:
        return f"No speech could be recognised: {speech_recognition_result.no_match_details}"
    elif speech_recognition_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_recognition_result.cancellation_details
        error_msg = f"Speech Recognition canceled: {cancellation_details.reason}"
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            error_msg += "\n" + f"Error details: {cancellation_details.error_details}"
        return error_msg


def Text_To_Latex(text):
    matplotlib.use('Agg')
    saytex_compiler = Saytex()
    try:
      latex_result = saytex_compiler.to_latex(text)
    except:
      latex_result = "Error: Text Not Recognized in Latex"
    # Display Graph
    left, width, bottom, height = .25, .5, .25, .5; right = left + width; top = bottom + height
    fig = plt.figure()
    fontsize = 24 if len(text.split(" ")) < 30 else 20
    plt.text(0.5 *(left+right), 0.5*(bottom+top), "$"+ latex_result + "$", horizontalalignment='center', verticalalignment='center', fontsize=fontsize) # r"$%s$" % latex_result
    plt.axis('off')
    return latex_result, fig

app = Flask(__name__)

transcript = ""
@app.route('/', methods=['GET','POST'])
def main(): 
  transcript = ""
  if request.method == 'POST':
    if "audio-file" in request.files:
      f = request.files["audio-file"]
      segment = AudioSegment.from_file(f.stream)
      segment.export("static/audio/sam.wav", format="wav")

      try:
        transcript = Speech_To_Text("static/audio/sam.wav")
        latex,fig = Text_To_Latex(transcript)

        image_path = "static/images/latex_fig/test.png"
        fig.savefig(image_path)
      except:
        print("Erreur de conversion Audio")

      print(transcript)
      return render_template('main.html')
    else:
      text2speech()
      return render_template('main.html')
  else:
    return render_template('main.html',transcript=transcript)

@app.route('/listening', methods=['GET','POST'])
def listen():
    # latex,fig = Text_To_Latex("x squared plus 5")

    image_path = "static/images/latex_fig/test.png"
    # fig.savefig(image_path)
    return render_template('main.html',message="test",image_path=image_path)

@app.route('/test', methods=['GET','POST'])
def test(): 
  if request.method == 'POST':
    
    return render_template("test.html")
  return render_template('test.html')

if __name__ == '__main__':
    app.run(debug = True)